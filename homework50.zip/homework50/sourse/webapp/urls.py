from django.urls import path
from . import views, cat

urlpatterns = [
    path('', views.simulator, name='simulator'),
    path('cat_stats', views.cat_stats, name='cat_stats'),

]
