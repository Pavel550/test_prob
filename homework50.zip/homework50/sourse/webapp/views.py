from django.shortcuts import render, HttpResponseRedirect
from webapp.cat_form import CatForm
from webapp.cat import Cat

# Create your views here.


def simulator(request):
    if request.method == 'POST':
        form = CatForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            cat = Cat(name)
            request.session['cat']  = cat.name
            return HttpResponseRedirect('cat_stats')
    else:
        form = CatForm()
    return render(request, 'simulator.html', {'form': form})


def cat_stats(request):
    cat = Cat(request.session['cat'])
    avatar = cat.avatar()

    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'feed':
            cat.feed()
        elif action == 'play':
            cat.play()
        elif action == 'sleep':
            cat.sleeping()
    return render(request, 'cat_stats.html', {'cat': cat, 'avatar': avatar})


