class Cat():
    def __init__(self, name):
        self.name = name
        self.age = 1
        self.hungry = 40
        self.happy = 40

    def feed(self):
       self.hungry = min(self.hungry + 15, 100)
       self.happy = min(self.happy + 5, 100)
       if self.hungry > 100:
            self.happy = max(self.happy - 30)
       self.save()

    def play(self):
       self.happy = min(self.happy + 15, 100)
       self.hungry = max(self.hungry - 10, 0)
       if self.happy == 0:
            self.hungry = 0
       self.save()

    def sleep(self):
        self.happy -= 5
        self.save()

    def sleeping(self):
        return self.happy == 0

    def avatar(self):
        if self.happy >= 30:
            return 'images/logo.png'
        elif self.happy <= 70:
            return 'images/cat3.png'
        else:
            return 'images/cat2.png'